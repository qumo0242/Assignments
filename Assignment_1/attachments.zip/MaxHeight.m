function hmax = MaxHeight(r,Wp,Wb,MW)
WB = BalloonWeight(r,Wp,Wb,MW);
h = 0;
WA = DisplacedWeight(r,h);

while WA > WB
    h = h + 10;
    WA = DisplacedWeight(r,h);
end
hmax = h;
end