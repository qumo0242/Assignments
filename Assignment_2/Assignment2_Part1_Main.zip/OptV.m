function [v] = OptV(th)
global Y0 success
v = 0;
tol = 1e-4;
dv = 1;
backwards = 0;
maxIter = 1e4;
i = 1;
while abs(dv) > tol && i <maxIter
    vx = v*cos(th); vy = v*sin(th);
    y0 = Y0 + [0 0 vx vy 0 0 0 0];
    options = odeset('Events',@TerminationCond);
    [t,y] = ode45(@(t,y)ThreeBody(t,y),[0,1e7],y0,options);
    if success == 3
        if ~backwards
            dv = dv/-10;
            backwards = 1;
        end
    else
        if backwards
            dv = dv/-10;
            backwards = 0;
        end
    end
    v = v+dv;
    i = i+1;
end

end