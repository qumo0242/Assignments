clear all
close all
clc

%Setting up initial conditions as global variables:
global mM mE mS rM rE G success Y0
mM = 7.34767309*10^22; %kg (Mass of the Moon)
mE = 5.97219*10^24; %kg (Mass of the Earth)
mS = 28833; %kg (Mass of the Space Craft)
rM = 1737100; %m (Radius of the Moon)
rE = 6371000; %m (Radius of the Earth)
G = 6.674*10^(-11); %N(m/kg)^2
success = 0;

%Setting up initial velocities and positions:
dES(1) = 338000000; %m (Distance From Earth to the Space Craft)
ThetaS = 50*pi/180; %Radians (Angle of the Space Craft)
vS(1) = 1000; %m/s (Velocity of the Space Craft)
xS(1) = dES(1)*cos(ThetaS); %m  (Horizontal Position of the Space Craft)
yS(1) = dES(1)*sin(ThetaS); %m  (Vertical Position of the Space Craft)
vSX(1) = vS(1)*cos(ThetaS); %m  (Horizontal Velocity of the Space Craft)
vSY(1) = vS(1)*sin(ThetaS); %m  (Vertical Velocity of the Space Craft)

dEM(1) = 384403000; %m (Distance From the Earth to the Moon)
ThetaM = 42.5*pi/180; %Radians (Angle of the Moon)
vM(1) = sqrt((G*mE^2)/((mE+mM)*dEM(1))); %m/s (Velocity of the Moon)
xM(1) = dEM(1)*cos(ThetaM); %m  (Horizontal Position of the Moon)
yM(1) = dEM(1)*sin(ThetaM); %m  (Vertical Position of the Moon)
vMX(1) = -vM(1)*sin(ThetaM); %m  (Horizontal Velocity of the Moon)
vMY(1) = vM(1)*cos(ThetaM); %m  (Vertical Velocity of the Moon)
Y0 = [xS(1),yS(1),vSX(1),vSY(1),xM(1),yM(1),vMX(1),vMY(1)]; %Vector of Initial Conditions
%[thmin] = fminbnd(@OptV,0,2*pi);

thi = 1; vi = thi;
for th = 0:.01:2*pi
    T(thi)=th;
    vi = 1;
    for v = 0:.1:200
    vx = v*cos(th); vy = v*sin(th);
    y0 = Y0 + [0 0 vx vy 0 0 0 0];
    options = odeset('Events',@TerminationCond);
    [t,y] = ode45(@(t,y)ThreeBody(t,y),[0,1e7],y0,options);
    V(vi)= v;S(thi,vi)=success;
    vi = vi+1;
    end
    thi = thi+1;
end
contour(T,V,S') 
    